create definer = lab_1153104193@`%` trigger insert_employee
    before insert
    on e2_employee
    for each row
begin
/**trigger body**/
    if(new.SUPERSSN is NULL AND new.DNO is not NULL)
        THEN set new.SUPERSSN = (select MGRSSN FROM `e2_department` WHERE `e2_department`.DNO = new.DNO);
    end if;
end;

