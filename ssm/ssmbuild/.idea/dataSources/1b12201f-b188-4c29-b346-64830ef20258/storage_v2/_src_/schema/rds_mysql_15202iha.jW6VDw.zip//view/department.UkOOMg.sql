create definer = lab_1153104193@`%` view department as
select `rds_mysql_15202iha`.`e3_department`.`departmentNo`   AS `departmentNo`,
       `rds_mysql_15202iha`.`e3_department`.`departmentName` AS `departmentName`,
       `rds_mysql_15202iha`.`e3_department`.`factoryName`    AS `factoryName`,
       `rds_mysql_15202iha`.`e3_department`.`leaderNo`       AS `leaderNo`
from `rds_mysql_15202iha`.`e3_department`
where (`rds_mysql_15202iha`.`e3_department`.`factoryName` = 'A');

