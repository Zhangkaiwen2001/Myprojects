create definer = lab_1153104193@`%` view employee_zhonghong as
select `rds_mysql_15202iha`.`e2_employee`.`ENAME`    AS `ENAME`,
       `rds_mysql_15202iha`.`e2_employee`.`ESSN`     AS `ESSN`,
       `rds_mysql_15202iha`.`e2_employee`.`ADDRESS`  AS `ADDRESS`,
       `rds_mysql_15202iha`.`e2_employee`.`SALARY`   AS `SALARY`,
       `rds_mysql_15202iha`.`e2_employee`.`SUPERSSN` AS `SUPERSSN`,
       `rds_mysql_15202iha`.`e2_employee`.`DNO`      AS `DNO`
from `rds_mysql_15202iha`.`e2_employee`
where (`rds_mysql_15202iha`.`e2_employee`.`SUPERSSN` = (select `rds_mysql_15202iha`.`e2_employee`.`ESSN`
                                                        from `rds_mysql_15202iha`.`e2_employee`
                                                        where (`rds_mysql_15202iha`.`e2_employee`.`ENAME` = '张红')));

