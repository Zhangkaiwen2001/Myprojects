create definer = lab_1153104193@`%` trigger work_time
    before update
    on e2_works_on
    for each row
begin
/**trigger body**/
    if(40 < (select sum(new.HOURS_PER_WEEK)
        FROM `works_on`
        WHERE `works_on`.ESSN = new.ESSN))
        THEN set new.HOURS_PER_WEEK = old.HOURS_PER_WEEK;
    end if;
end;

