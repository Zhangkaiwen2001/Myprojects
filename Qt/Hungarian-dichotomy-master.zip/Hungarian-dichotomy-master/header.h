//
// Created by Wentw on 2018/12/27.
//

#ifndef UNTITLED_CLASS_HEADER_H
#define UNTITLED_CLASS_HEADER_H

#include <iostream>
#include <string>
#include <memory.h>
#include <algorithm>
#include <fstream>
#include <vector>
#define N 20    //教师最大个数
#define M 20    //课程最大个数
using namespace std;



#endif //UNTITLED_CLASS_HEADER_H
